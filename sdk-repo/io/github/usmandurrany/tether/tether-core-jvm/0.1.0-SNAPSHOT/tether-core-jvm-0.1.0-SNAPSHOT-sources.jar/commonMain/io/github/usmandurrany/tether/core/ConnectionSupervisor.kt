package io.github.usmandurrany.tether.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random
import kotlin.time.TimeSource

/** An authenticated stream as the supervisor sees it. [XmppSession] implements it. */
public interface LiveSession {
    public val jid: FullJid

    /**
     * Suspends until the stream ends. Returns null when the server closed it
     * cleanly, or the error that ended it. A stream error is reported as an
     * [XmppNegotiationException] with [XmppNegotiationException.streamError] set.
     */
    public suspend fun awaitClosed(): Throwable?

    /** Checks the server is still answering (SM `<r/>` or XEP-0199 ping). The supervisor applies the timeout. */
    public suspend fun probe(): Boolean

    /** Closes the stream. Must be idempotent and must not suspend. */
    public fun close()

    /**
     * Ends the stream politely (flush, then `</stream:stream>`) so the server
     * drops the session instead of keeping it resumable. Used by
     * [ConnectionSupervisor.disconnect]; the supervisor applies a timeout and
     * calls [close] afterwards either way.
     */
    public suspend fun closeGracefully() {
        close()
    }
}

/** Opens one session. Must clean up after itself when cancelled or when it fails. */
public fun interface SessionOpener {
    public suspend fun open(): LiveSession
}

/**
 * The OS signals a connection reacts to. Platform glue (such as the Android
 * module) feeds these from the app lifecycle and the network monitor.
 */
public interface ConnectionControls {
    /** See [ConnectionSupervisor.setForeground]. */
    public fun setForeground(foreground: Boolean)

    /** See [ConnectionSupervisor.networkChanged]. */
    public fun networkChanged(available: Boolean, id: String? = null, kind: String? = id)

    /** See [ConnectionSupervisor.wake]. */
    public fun wake()
}

/** What the connection is doing. Observe [ConnectionSupervisor.state]. */
public sealed interface ConnectionState {
    /** Not wanted: [ConnectionSupervisor.connect] has not been called, or [ConnectionSupervisor.disconnect] was. */
    public data object Idle : ConnectionState

    /** Wanted, but the OS reports no network. Nothing is attempted until one appears. */
    public data object WaitingForNetwork : ConnectionState

    /** An attempt is running. [attempt] counts from 1 since the last success. */
    public data class Connecting(val attempt: Int) : ConnectionState

    public data class Online(val jid: FullJid) : ConnectionState

    /** Waiting before the next attempt. */
    public data class Backoff(val attempt: Int, val delayMillis: Long, val lastError: Throwable?) : ConnectionState

    /**
     * Wanted, but closed on purpose because the app is in the background
     * ([BackgroundMode.CLOSE] or [BackgroundMode.DETACH]). Reconnects when the
     * app returns to the foreground, or on an explicit [ConnectionSupervisor.connect].
     */
    public data object Paused : ConnectionState

    /** Stopped on an error retrying cannot fix (bad credentials, certificate, conflict). Only [ConnectionSupervisor.connect] restarts. */
    public data class Terminal(val error: Throwable) : ConnectionState
}

/** The outcome for one caller of [ConnectionSupervisor.connect]. */
public sealed interface ConnectResult {
    public data class Connected(val jid: FullJid) : ConnectResult
    public data class Failed(val error: Throwable) : ConnectResult
    /** [ConnectionSupervisor.disconnect] was called before the connection came up. */
    public data object Cancelled : ConnectResult
}

/** What happens to the connection while the app is in the background. */
public enum class BackgroundMode {
    /**
     * End the session cleanly (`</stream:stream>`). The server marks the account
     * offline at once, so new messages go to offline storage and push
     * notifications (XEP-0357) on every server. Coming back is a fresh login.
     */
    CLOSE,

    /**
     * Cut the socket but keep the XEP-0198 session resumable. The server sees
     * the drop at once and holds the session for its resume window; coming back
     * resumes without a login and replays what was missed. Whether the server
     * sends push notifications for a held session depends on the server.
     */
    DETACH,

    /** Keep the connection; the app should mark it inactive with CSI (XEP-0352). */
    STAY_CONNECTED,
}

/** Timing for reconnects and liveness checks (design §4.3, §4.4). */
public data class ReconnectPolicy(
    /** Backoff base: the n-th retry waits a random time in [0, min(max, base·2^(n-2))]. The first retry is immediate. */
    val baseDelayMillis: Long = 1_000,
    val maxDelayMillis: Long = 120_000,
    /** A probe that gets no answer in this time counts as failed. */
    val probeTimeoutMillis: Long = 10_000,
    /**
     * A session that drops sooner than this after coming up counts as a failed
     * attempt (with backoff), so a server that accepts and immediately kicks us
     * cannot cause a tight reconnect loop. Later drops reconnect immediately.
     */
    val stableSessionMillis: Long = 30_000,
    /** In the background the radio is costlier and the OS stricter: wait longer between retries. */
    val backgroundMaxDelayMillis: Long = 600_000,
    /** Background networks are often slower to wake; give probes longer. */
    val backgroundProbeTimeoutMillis: Long = 20_000,
    /** Upper bound for [ConnectionSupervisor.disconnect]'s polite close before the socket is cut. */
    val gracefulCloseMillis: Long = 5_000,
    val backgroundMode: BackgroundMode = BackgroundMode.CLOSE,
    /**
     * How long the app must stay in the background before the connection is
     * closed, so a quick switch to the camera or share sheet does not cause a
     * disconnect, a push, and a reconnect. 0 closes immediately.
     */
    val backgroundCloseDelayMillis: Long = 5_000,
) {
    init {
        require(baseDelayMillis > 0 && maxDelayMillis >= baseDelayMillis) { "Invalid backoff bounds" }
        require(backgroundMaxDelayMillis >= baseDelayMillis) { "Invalid background backoff" }
        require(probeTimeoutMillis > 0 && backgroundProbeTimeoutMillis > 0 && stableSessionMillis >= 0) { "Invalid timeouts" }
        require(gracefulCloseMillis >= 0 && backgroundCloseDelayMillis >= 0)
    }
}

/**
 * Keeps one account connected (design §4.1, §4.1a).
 *
 * Every trigger (API calls, network changes, push wake-ups, timers, socket and
 * probe results) is an intent sent to a single actor coroutine, which alone
 * owns the state. That gives these guarantees:
 *
 * - At most one attempt runs and at most one session is live, so overlapping
 *   triggers can never open a second connection.
 * - Each attempt has an epoch. Results from an older epoch are dropped, and a
 *   session they carry is closed, so a late event can never tear down the
 *   current connection.
 * - An online session is closed only when a probe fails, the server ends it,
 *   or [disconnect] is called. Wake-ups and network changes only trigger a probe.
 * - Terminal errors stop retrying, which also stops two clients with the same
 *   resource from kicking each other in a loop.
 *
 * Use one supervisor per account per process; [ConnectionRegistry] enforces that.
 *
 * While online, an idle probe runs on the interval [AdaptiveKeepalive] learned
 * for the current network, so a dead link is found even when nothing is sent.
 *
 * @param scope where the actor runs. Cancelling it stops the supervisor and closes the session.
 * @param keepalive learned idle intervals; null turns idle probing off.
 * @param clock monotonic milliseconds, injectable for tests.
 */
public class ConnectionSupervisor(
    private val scope: CoroutineScope,
    private val opener: SessionOpener,
    private val policy: ReconnectPolicy = ReconnectPolicy(),
    private val random: Random = Random.Default,
    private val clock: () -> Long = monotonicMillis(),
    private val keepalive: AdaptiveKeepalive? = AdaptiveKeepalive(),
) : ConnectionControls {
    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    public val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val intents = Channel<Intent>(Channel.UNLIMITED)

    private sealed interface Intent {
        class Connect(val result: CompletableDeferred<ConnectResult>) : Intent
        class Disconnect(val done: CompletableDeferred<Unit>) : Intent
        data object Wake : Intent
        class Network(val available: Boolean, val id: String?, val kind: String?) : Intent
        class AttemptDone(val epoch: Long, val session: LiveSession?, val error: Throwable?) : Intent
        class SessionEnded(val epoch: Long, val cause: Throwable?) : Intent
        class ProbeDone(val epoch: Long, val ok: Boolean) : Intent
        class TimerFired(val token: Long) : Intent
        class KeepaliveDue(val token: Long) : Intent
        class Foreground(val foreground: Boolean) : Intent
        class BackgroundDue(val token: Long) : Intent
    }

    // Everything below is touched only by the actor coroutine.
    private var wanted = false
    private var epoch = 0L
    private var failures = 0
    private var networkAvailable = true
    private var networkId: String? = null
    private var networkKind: String? = null
    private var attemptNetworkId: String? = null
    private var attemptJob: Job? = null
    /** Cancelled attempts that have not finished yet (a blocking connect may ignore cancellation). */
    private val draining = ArrayList<Job>()
    private var session: LiveSession? = null
    private var onlineSince = 0L
    private var watchJob: Job? = null
    private var probeJob: Job? = null
    private var timerJob: Job? = null
    private var timerToken = 0L
    private var keepaliveJob: Job? = null
    private var keepaliveToken = 0L
    private var probeIsIdle = false
    private var foreground = true
    private var backgroundJob: Job? = null
    private var backgroundToken = 0L
    private val waiters = ArrayList<CompletableDeferred<ConnectResult>>()

    private val actor = scope.launch {
        try {
            for (intent in intents) handle(intent)
        } finally {
            shutdown()
        }
    }

    /**
     * Asks to be connected and waits for the outcome. Concurrent callers share
     * the same attempt. Returns immediately when already online (and checks the
     * connection in the background). Keeps waiting through retries and while
     * there is no network; wrap in a timeout if needed.
     */
    public suspend fun connect(): ConnectResult {
        val result = CompletableDeferred<ConnectResult>()
        if (intents.trySend(Intent.Connect(result)).isFailure) return ConnectResult.Cancelled
        return result.await()
    }

    /** Stops retrying and closes the session. Pending [connect] callers get [ConnectResult.Cancelled]. */
    public suspend fun disconnect() {
        val done = CompletableDeferred<Unit>()
        if (intents.trySend(Intent.Disconnect(done)).isFailure) return
        done.await()
    }

    /**
     * A hint that now is a good time to be connected: app came to the
     * foreground, or a push arrived. Probes a live session, or skips the
     * backoff wait. Ignored unless [connect] was called.
     */
    override fun wake() {
        intents.trySend(Intent.Wake)
    }

    /**
     * Reports the validated default network. [id] identifies the network (for
     * example the Android `Network` handle); a change of id means a network switch.
     * Callers should debounce bursts of OS callbacks before calling this.
     *
     * [kind] is what keepalive timing is learned for, such as "wifi" or
     * "cell:310260". It should stay the same when the same kind of network comes
     * back, whereas [id] changes on every reconnect. Defaults to [id].
     */
    override fun networkChanged(available: Boolean, id: String?, kind: String?) {
        intents.trySend(Intent.Network(available, id, kind))
    }

    /**
     * Tells the supervisor whether the app is in the foreground. Coming to the
     * foreground acts like [wake]; in the background, retries back off further
     * and probes get more time.
     */
    override fun setForeground(foreground: Boolean) {
        intents.trySend(Intent.Foreground(foreground))
    }

    /** Stops the actor and closes the session. The supervisor cannot be reused. */
    public fun close() {
        intents.close()
        actor.cancel()
    }

    private fun handle(intent: Intent) {
        when (intent) {
            is Intent.Connect -> onConnect(intent.result)
            is Intent.Disconnect -> onDisconnect(intent.done)
            Intent.Wake -> if (wanted) onWake()
            is Intent.Network -> {
                networkKind = if (intent.available) intent.kind else null
                onNetwork(intent.available, intent.id)
            }
            is Intent.AttemptDone -> onAttemptDone(intent)
            is Intent.SessionEnded -> if (intent.epoch == epoch && session != null) onSessionEnded(intent.cause)
            is Intent.ProbeDone -> if (intent.epoch == epoch && session != null) onProbeDone(intent.ok)
            is Intent.TimerFired -> if (intent.token == timerToken && _state.value is ConnectionState.Backoff) {
                timerJob = null
                startAttempt()
            }
            is Intent.KeepaliveDue -> if (intent.token == keepaliveToken && session != null) {
                keepaliveJob = null
                probe(idle = true)
            }
            is Intent.Foreground -> onForeground(intent.foreground)
            is Intent.BackgroundDue -> if (intent.token == backgroundToken && !foreground && wanted) {
                backgroundJob = null
                if (_state.value != ConnectionState.Paused && _state.value !is ConnectionState.Terminal) pause()
            }
        }
    }

    private fun onForeground(nowForeground: Boolean) {
        val was = foreground
        foreground = nowForeground
        if (was == nowForeground) return
        cancelBackgroundTimer()
        if (!wanted) return
        if (nowForeground) {
            when (_state.value) {
                ConnectionState.Paused -> {
                    failures = 0
                    startAttempt() // Resumes the held session when the server still has it.
                }
                else -> onWake()
            }
            return
        }
        if (policy.backgroundMode == BackgroundMode.STAY_CONNECTED) return
        if (policy.backgroundCloseDelayMillis == 0L) {
            pause()
            return
        }
        val token = backgroundToken
        backgroundJob = scope.launch {
            delay(policy.backgroundCloseDelayMillis)
            deliver(Intent.BackgroundDue(token))
        }
    }

    private fun cancelBackgroundTimer() {
        backgroundJob?.cancel()
        backgroundJob = null
        backgroundToken++
    }

    /** Closes the connection on purpose for the background, keeping [wanted]. */
    private fun pause() {
        when (policy.backgroundMode) {
            BackgroundMode.CLOSE -> closeSessionGracefully(null)
            else -> dropSession() // DETACH: an abrupt close leaves the SM session resumable.
        }
        cancelAttempt()
        cancelTimer()
        set(ConnectionState.Paused)
    }

    /** In the background with a closing mode, a lost connection waits for the foreground instead of retrying. */
    private val pausedByBackground: Boolean
        get() = !foreground && backgroundJob == null && policy.backgroundMode != BackgroundMode.STAY_CONNECTED

    private fun onDisconnect(done: CompletableDeferred<Unit>) {
        wanted = false
        closeSessionGracefully(done)
        stopEverything()
        set(ConnectionState.Idle)
        completeWaiters(ConnectResult.Cancelled)
    }

    /**
     * Detaches the live session and ends it politely in the background. A new
     * attempt waits for this, so the old session is gone before a new one opens.
     */
    private fun closeSessionGracefully(done: CompletableDeferred<Unit>?) {
        val closing = session
        val closingWatch = watchJob
        // Detach the session so dropSession does not cut it; it is closed politely below.
        session = null
        watchJob = null
        dropSession()
        if (closing == null) {
            done?.complete(Unit)
            return
        }
        val job = scope.launch {
            try {
                withTimeoutOrNull(policy.gracefulCloseMillis) { closing.closeGracefully() }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // Closing anyway below.
            } finally {
                closing.close()
                closingWatch?.cancel()
                done?.complete(Unit)
            }
        }
        draining += job
    }

    private fun onConnect(result: CompletableDeferred<ConnectResult>) {
        wanted = true
        when (val s = _state.value) {
            is ConnectionState.Online -> {
                result.complete(ConnectResult.Connected(s.jid))
                probe()
            }
            is ConnectionState.Connecting, ConnectionState.WaitingForNetwork -> waiters += result
            // An explicit connect() works in the background too, for example to handle a push.
            is ConnectionState.Backoff, ConnectionState.Idle, ConnectionState.Paused, is ConnectionState.Terminal -> {
                waiters += result
                failures = 0
                cancelTimer()
                startAttempt()
            }
        }
    }

    private fun onWake() {
        when (_state.value) {
            is ConnectionState.Online -> probe()
            is ConnectionState.Backoff -> {
                failures = 0
                cancelTimer()
                startAttempt()
            }
            // Joining an attempt, waiting for network, or stopped: a wake changes nothing.
            else -> Unit
        }
    }

    private fun onNetwork(available: Boolean, id: String?) {
        val wasAvailable = networkAvailable
        val previousId = networkId
        networkAvailable = available
        networkId = if (available) id else null
        if (!wanted) return
        when (_state.value) {
            // Never close a live session on suspicion; check it. A failed probe
            // then waits for the network or reconnects.
            is ConnectionState.Online -> if (!available || !wasAvailable || id != previousId) probe()
            is ConnectionState.Connecting -> when {
                !available -> {
                    cancelAttempt()
                    set(ConnectionState.WaitingForNetwork)
                }
                // The attempt was started on a network that is gone; start over on the new one.
                id != attemptNetworkId -> {
                    cancelAttempt()
                    startAttempt()
                }
            }
            is ConnectionState.Backoff -> if (!available) {
                cancelTimer()
                set(ConnectionState.WaitingForNetwork)
            } else if (!wasAvailable || id != previousId) {
                failures = 0
                cancelTimer()
                startAttempt()
            }
            ConnectionState.WaitingForNetwork -> if (available) {
                failures = 0
                startAttempt()
            }
            ConnectionState.Idle, ConnectionState.Paused, is ConnectionState.Terminal -> Unit
        }
    }

    private fun startAttempt() {
        check(attemptJob == null && session == null) { "An attempt or session is already active" }
        if (!networkAvailable) {
            set(ConnectionState.WaitingForNetwork)
            return
        }
        val myEpoch = ++epoch
        attemptNetworkId = networkId
        set(ConnectionState.Connecting(failures + 1))
        draining.removeAll { it.isCompleted }
        val previous = draining.toList()
        attemptJob = scope.launch {
            // Never overlap with a cancelled attempt that is still running.
            previous.joinAll()
            val outcome = try {
                Intent.AttemptDone(myEpoch, opener.open(), null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Intent.AttemptDone(myEpoch, null, e)
            }
            // No suspension point since open() returned, so this runs even if the attempt
            // was cancelled meanwhile; the actor then closes the session as stale.
            deliver(outcome)
        }
    }

    private fun onAttemptDone(done: Intent.AttemptDone) {
        if (done.epoch != epoch || _state.value !is ConnectionState.Connecting) {
            done.session?.close() // Stale: a newer attempt or a disconnect superseded it.
            return
        }
        attemptJob = null
        val opened = done.session
        if (opened != null) {
            session = opened
            onlineSince = clock()
            set(ConnectionState.Online(opened.jid))
            completeWaiters(ConnectResult.Connected(opened.jid))
            scheduleKeepalive()
            val myEpoch = epoch
            watchJob = scope.launch {
                val cause = try {
                    opened.awaitClosed()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    e
                }
                deliver(Intent.SessionEnded(myEpoch, cause))
            }
            return
        }
        val error = done.error ?: IllegalStateException("Attempt returned neither a session nor an error")
        if (isTerminal(error)) {
            stopTerminal(error)
        } else {
            failures++
            scheduleRetry(error)
        }
    }

    private fun onSessionEnded(cause: Throwable?) {
        val livedMillis = clock() - onlineSince
        dropSession()
        when {
            cause != null && isTerminal(cause) -> stopTerminal(cause)
            pausedByBackground -> set(ConnectionState.Paused)
            livedMillis < policy.stableSessionMillis -> {
                failures++
                scheduleRetry(cause)
            }
            else -> {
                failures = 0
                startAttempt()
            }
        }
    }

    private fun onProbeDone(ok: Boolean) {
        probeJob = null
        val idle = probeIsIdle
        probeIsIdle = false
        if (ok) {
            if (idle) keepalive?.onIdleSuccess(networkKind)
            scheduleKeepalive() // Any answered probe proves the link; restart the idle clock.
            return
        }
        // A link that dies while idle tells us this network's NAT forgets us sooner.
        if (idle) keepalive?.onIdleDeath(networkKind)
        dropSession()
        failures = 0
        if (pausedByBackground) set(ConnectionState.Paused) else startAttempt() // Waits for the network if there is none.
    }

    private fun probe(idle: Boolean = false) {
        val live = session ?: return
        if (probeJob != null) return // One probe at a time; its result answers every trigger.
        probeIsIdle = idle
        cancelKeepalive()
        val myEpoch = epoch
        val timeout = if (foreground) policy.probeTimeoutMillis else policy.backgroundProbeTimeoutMillis
        probeJob = scope.launch {
            val ok = try {
                withTimeoutOrNull(timeout) { live.probe() } ?: false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                false
            }
            deliver(Intent.ProbeDone(myEpoch, ok))
        }
    }

    /** `failures` is the number of consecutive failed attempts so far (at least 1 here). */
    private fun scheduleRetry(error: Throwable?) {
        val delayMillis = if (failures <= 1) 0L else backoffDelay(failures)
        if (delayMillis == 0L) {
            startAttempt()
            return
        }
        set(ConnectionState.Backoff(failures + 1, delayMillis, error))
        val token = ++timerToken
        timerJob = scope.launch {
            delay(delayMillis)
            deliver(Intent.TimerFired(token))
        }
    }

    private fun scheduleKeepalive() {
        val ka = keepalive ?: return
        if (session == null) return
        cancelKeepalive()
        val token = keepaliveToken
        val interval = ka.intervalFor(networkKind)
        keepaliveJob = scope.launch {
            delay(interval)
            deliver(Intent.KeepaliveDue(token))
        }
    }

    private fun cancelKeepalive() {
        keepaliveJob?.cancel()
        keepaliveJob = null
        keepaliveToken++
    }

    /** Full jitter: random in [0, min(cap, base·2^(n-2))]. */
    internal fun backoffDelay(failures: Int): Long {
        val exponent = (failures - 2).coerceIn(0, 30)
        val cap = if (foreground) policy.maxDelayMillis else policy.backgroundMaxDelayMillis
        val ceiling = minOf(cap, policy.baseDelayMillis shl exponent).coerceAtLeast(1)
        return random.nextLong(ceiling + 1).coerceAtLeast(1)
    }

    private fun stopTerminal(error: Throwable) {
        stopEverything()
        set(ConnectionState.Terminal(error))
        completeWaiters(ConnectResult.Failed(error))
    }

    private fun dropSession() {
        watchJob?.cancel()
        watchJob = null
        probeJob?.cancel()
        probeJob = null
        probeIsIdle = false
        cancelKeepalive()
        session?.close()
        session = null
        epoch++ // Anything still in flight for the old session is now stale.
    }

    private fun cancelAttempt() {
        attemptJob?.let {
            it.cancel() // If it still opens a session, the result arrives and is closed as stale.
            draining += it
        }
        attemptJob = null
        epoch++
    }

    private fun cancelTimer() {
        timerJob?.cancel()
        timerJob = null
        timerToken++
    }

    private fun stopEverything() {
        cancelAttempt()
        cancelTimer()
        dropSession()
    }

    private fun shutdown() {
        attemptJob?.cancel()
        timerJob?.cancel()
        keepaliveJob?.cancel()
        backgroundJob?.cancel()
        watchJob?.cancel()
        probeJob?.cancel()
        session?.close()
        session = null
        completeWaiters(ConnectResult.Cancelled)
        // Close sessions from attempts that finish after shutdown.
        intents.close()
        while (true) {
            val leftover = intents.tryReceive().getOrNull() ?: break
            when (leftover) {
                is Intent.AttemptDone -> leftover.session?.close()
                is Intent.Connect -> leftover.result.complete(ConnectResult.Cancelled)
                is Intent.Disconnect -> leftover.done.complete(Unit)
                else -> Unit
            }
        }
    }

    private fun deliver(intent: Intent) {
        if (intents.trySend(intent).isFailure && intent is Intent.AttemptDone) intent.session?.close()
    }

    private fun completeWaiters(result: ConnectResult) {
        waiters.forEach { it.complete(result) }
        waiters.clear()
    }

    private fun set(state: ConnectionState) {
        _state.value = state
    }
}

/**
 * Errors retrying cannot fix. Certificate and login failures need the user;
 * `conflict` means another client took our resource, and retrying would make
 * the two kick each other forever.
 */
internal fun isTerminal(error: Throwable): Boolean {
    if (error !is XmppNegotiationException) return false
    val condition = error.streamError
    if (condition != null) return condition in TERMINAL_STREAM_ERRORS
    return !error.failure.retryable
}

private val TERMINAL_STREAM_ERRORS = setOf(
    "conflict",
    "not-authorized",
    "policy-violation",
    "host-unknown",
    "improper-addressing",
    "unsupported-version",
    "invalid-namespace",
)

private fun monotonicMillis(): () -> Long {
    val start = TimeSource.Monotonic.markNow()
    return { start.elapsedNow().inWholeMilliseconds }
}
